# traaittPlatform® Blockchain Explorer

This Blockchain Explorer is entirely self contained.

Just drop the files in a publicly accessible web folder and you've got your own copy of the explorer.
##### (c) 2020 traaittPlatform® Team
###### (c) 2018-2019 TurtlePay® Development Team
